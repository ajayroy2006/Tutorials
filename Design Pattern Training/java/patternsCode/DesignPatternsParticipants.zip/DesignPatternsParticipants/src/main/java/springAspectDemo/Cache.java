package springAspectDemo;

public interface Cache {

	public void setCacheSize(int size);

}